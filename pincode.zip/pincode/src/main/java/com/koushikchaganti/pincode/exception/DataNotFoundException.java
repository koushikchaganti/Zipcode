package com.koushikchaganti.pincode.exception;

public class DataNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3369387488742071297L;

	public DataNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}
