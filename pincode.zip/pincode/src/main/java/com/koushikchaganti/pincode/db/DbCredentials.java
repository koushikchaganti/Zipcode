package com.koushikchaganti.pincode.db;

public interface DbCredentials {
	public String db_conn_str = "jdbc:oracle:thin:@mydatabase.c9nna2qkgrap.us-east-1.rds.amazonaws.com:1521:orcl";
	public String db_user = "Koushik";
	public String db_password = "Koushik93";
}

